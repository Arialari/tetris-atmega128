#define F_CPU 16000000UL
#include<avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#include "LTM022A69B.h"
#include "LCD_lib.h"
#include"touch.h"

unsigned char read_res ;
typedef struct 
{
	unsigned int  x;//LCD coordinates
	unsigned int  y;
	unsigned long x_ad_val; //ADC value
	unsigned long y_ad_val;						   	    
	unsigned char pen_status;//The pen of the state
}_touch_dot;

extern _touch_dot touch_dot;

void Timer_8bit_Init();

int isBox(int x1, int y1, int x2, int y2);

short g_state=0;
short play_n=2;

int sec=0;
int seed=0;
int dlay=0;
int a_dlay=0;
int input_d=0;
short inputed=0;

short er=0;
short op_gg=0;
short gg=0;
short in_stack=0;
short in_l=0;
short temp_down=0;

typedef struct units {
	short arr[4][4];
	struct unit *next;
} units;

short map[17][13]={0};
units unit[7];
units unit0_1, unit1_1, unit1_2, unit1_3, unit2_1, unit2_2, unit2_3, unit3_1,unit3_2,unit3_3,unit4_1,unit5_1;
int clr[8]={GRAYBLUE,ORANGE,YELLOW,RED,WHITE,BLACK,PINK,DARKBLUE};
int gamespeed=10;
short line=3, sort=3, now=0, x=0;
short nn=0,mm=0;
int score = 0;
short next=0;

void unit_init() // ������ ���������, ���� ��ȯ ������...
{
	int i=0,j=0;
	for(i=0;i<3;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[0].arr[i][j]=0;
		}
	}
	for(j=0;j<4;j++)
		unit[0].arr[3][j]=1;
	unit[0].next=&unit0_1;

	for(i=0;i<4;i++)
	{
		for(j=0;j<3;j++)
		{
			unit0_1.arr[j][i]=0;
		}
	}
	for(j=0;j<4;j++)
		unit0_1.arr[j][0]=1;

	unit0_1.next=&unit[0];
	// ���� ��� ���� (0��° ���)

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[1].arr[i][j]=0;
		}
	}
	unit[1].arr[2][0]=2;
	unit[1].arr[3][0]=2;
	unit[1].arr[3][1]=2;
	unit[1].arr[3][2]=2;
	// ������ ���
	unit[1].next = &unit1_1;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit1_1.arr[i][j]=0;
		}
	}
	unit1_1.arr[1][1]=2;
	unit1_1.arr[2][1]=2;
	unit1_1.arr[3][1]=2;
	unit1_1.arr[3][0]=2;
	// ���� ���
	unit1_1.next = &unit1_2;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit1_2.arr[i][j]=0;
		}
	}
	unit1_2.arr[2][0]=2;
	unit1_2.arr[2][1]=2;
	unit1_2.arr[2][2]=2;
	unit1_2.arr[3][2]=2;

	unit1_2.next = &unit1_3;
	// �����ڸ��
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit1_3.arr[i][j]=0;
		}
	}
	unit1_3.arr[1][0]=2;
	unit1_3.arr[1][1]=2;
	unit1_3.arr[2][0]=2;
	unit1_3.arr[3][0]=2;

	unit1_3.next = &unit[1];
	//���� ���
	// unit[1] �� �� ���� ��--------------------------unit[1]

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[2].arr[i][j]=0;
		}
	}
	unit[2].arr[2][2]=3;
	unit[2].arr[3][0]=3;
	unit[2].arr[3][1]=3;
	unit[2].arr[3][2]=3;
	// ������ ���
	unit[2].next = &unit2_1;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit2_1.arr[i][j]=0;
		}
	}
	unit2_1.arr[1][1]=3;
	unit2_1.arr[2][1]=3;
	unit2_1.arr[3][1]=3;
	unit2_1.arr[1][0]=3;
	// ���� ���
	unit2_1.next = &unit2_2;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit2_2.arr[i][j]=0;
		}
	}
	unit2_2.arr[2][0]=3;
	unit2_2.arr[2][1]=3;
	unit2_2.arr[2][2]=3;
	unit2_2.arr[3][0]=3;

	unit2_2.next = &unit2_3;
	// ���ڸ��
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit2_3.arr[i][j]=0;
		}
	}
	unit2_3.arr[1][0]=3;
	unit2_3.arr[3][1]=3;
	unit2_3.arr[2][0]=3;
	unit2_3.arr[3][0]=3;

	unit2_3.next = &unit[2];
	// ���� ���
	// unit[2] -------------------------- unit[2]---------------------------

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[3].arr[i][j]=0;
		}
	}
	unit[3].arr[2][1]=4;
	unit[3].arr[3][0]=4;
	unit[3].arr[3][1]=4;
	unit[3].arr[3][2]=4;
	// ���� ���
	unit[3].next = &unit3_1;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit3_1.arr[i][j]=0;
		}
	}
	unit3_1.arr[1][1]=4;
	unit3_1.arr[2][1]=4;
	unit3_1.arr[3][1]=4;
	unit3_1.arr[2][0]=4;
	// ���� ���
	unit3_1.next = &unit3_2;

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit3_2.arr[i][j]=0;
		}
	}
	unit3_2.arr[2][0]=4;
	unit3_2.arr[2][1]=4;
	unit3_2.arr[2][2]=4;
	unit3_2.arr[3][1]=4;

	unit3_2.next = &unit3_3;
	// ���ڸ��
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit3_3.arr[i][j]=0;
		}
	}
	unit3_3.arr[1][0]=4;
	unit3_3.arr[2][1]=4;
	unit3_3.arr[2][0]=4;
	unit3_3.arr[3][0]=4;

	unit3_3.next = &unit[3];
	// ���� ���
	// unit[3] -------------------------------- unit[3] ��

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[4].arr[i][j]=0;
		}
	}
	unit[4].arr[2][0]=5;
	unit[4].arr[2][1]=5;
	unit[4].arr[3][1]=5;
	unit[4].arr[3][2]=5;

	//���� ��� 

	unit[4].next=&unit4_1;
	
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit4_1.arr[i][j]=0;
		}
	}
	unit4_1.arr[1][1]=5;
	unit4_1.arr[2][1]=5;
	unit4_1.arr[2][0]=5;
	unit4_1.arr[3][0]=5;

	unit4_1.next=&unit[4];
	//�װ� ���� ���
	//unit[4] ------------------------- unit[4] ����

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[5].arr[i][j]=0;
		}
	}
	unit[5].arr[2][1]=6;
	unit[5].arr[2][2]=6;
	unit[5].arr[3][1]=6;
	unit[5].arr[3][0]=6;

	//���� ��� 

	unit[5].next=&unit5_1;
	
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit5_1.arr[i][j]=0;
		}
	}
	unit5_1.arr[1][0]=6;
	unit5_1.arr[2][1]=6;
	unit5_1.arr[2][0]=6;
	unit5_1.arr[3][1]=6;

	unit5_1.next=&unit[5];
	// �� ��� 
	//unit[5] ------------------------- unit[5] ����

	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			unit[6].arr[i][j]=0;
		}
	}
	unit[6].arr[2][0]=7;
	unit[6].arr[2][1]=7;
	unit[6].arr[3][0]=7;
	unit[6].arr[3][1]=7;

	unit[6].next=&unit[6];
	//����� unit[6] ----------------------------------- unit[6] ��
}

void display_touch_debug()
{        //ADC results show
        lcd_display_string("READ SUCCESS:",BLACK,GREEN,1,3);
        lcd_display_number(14,3,read_res,6);

        lcd_display_string("X AD Val:",BLACK,GREEN,1,4);
        lcd_display_number(10,4,touch_dot.x_ad_val,6);

        lcd_display_string("Y AD Val:",BLACK,GREEN,1,5);
        lcd_display_number(10,5,touch_dot.y_ad_val,6);

        //Display coordinates
        lcd_display_string("X:",BLACK,GREEN,1,6);
        lcd_display_number(10,6,touch_dot.x,5);
        lcd_display_string("Y:",BLACK,GREEN,1,7);
        lcd_display_number(10,7,touch_dot.y,5);
}

void interruptlnit() // ���ͷ�Ʈ ����
{
	SREG &= 0X7f;
	EICRA = 0Xff;
	EICRB = 0xff;
	EIMSK = 0xff;
	SREG |= 0x80;
}

void port_init() // ��Ʈ ����
{
	DDRF = 0xff;
	PORTF = 0xff;
}

ISR(TIMER0_OVF_vect) // Ÿ�̸� ���ͷ�Ʈ
{
	if(g_state==1)
	{
		TCNT0 = 100; // 10msec
		if(seed%10==0) sec++;
		seed++;
		if(dlay>0) dlay--; // �����Է� ���� ������
		if(a_dlay>0) a_dlay--; // ���ͷ�Ʈ ä�͸� ���� ������
	
		if(sec==gamespeed) // �ð� ������ ��ĭ �Ʒ���
		{ 
			sec=0;
			temp_down=1;
			if(play_n==2) active_input(); // 2�ο��ϰ�� ���� ���� ������ ���
			if(in_l) while(in_l != 0 ) { in_line(); in_l--; }		// 2�ο� �г�Ƽ ����
		}
		if(input_d>0) input_d--; // ���ͷ�Ʈ ��ü �ð� ����
	}
}

ISR(INT2_vect) // �Է� ���ͷ�Ʈ
{
	if(input_d==0)	{ input_d=100; a_dlay=10; in_stack+=1; } // �� ������ �ð� �ʱ�ȭ
	else
	{
		if(a_dlay==0)	
		{ 
			if(in_stack<2) in_stack+=1; 
			a_dlay=10; 
		}
	}
	
}

void active_input() // 2�ο� �Է� ���ӿ� ����
{
	switch(in_stack)
	{
		case 0 : break;
		case 1 : in_l+=1;break;
		case 2 : op_gg=1;break;
		default : break;
	}
	in_stack=0;
}

void c_left() // ���� Ŭ����
{	
	if(dlay==0)	{ moveleft(); dlay=5; }
}

void c_down() // �Ʒ� Ŭ����
{	
	if(dlay==0)	{ 	
		if(line<16)
			movedown();
		else
		{
			stack_unit();
			er_line();
			insert2m(next);
		}	
		dlay=5;
	}
}

void c_right() // ������ Ŭ����
{	
	if(dlay==0)	{ moveright(); dlay=5; }
}

void c_turn() // ������ȯ Ŭ����
{
	if(dlay==0) { turning(); dlay=5; }
}

void c_up() // ȭ�� Ŭ����
{
	if(dlay==0) 
	{ 
		while(line!=3) 
		{
			if(line<16)
				movedown();
			else
			{
				stack_unit();
				er_line();
				insert2m(next);
			}	
		}
		dlay=5;
	}
}

void insert2m(int u) // ���� ���� ���� �� ���� ���� ����
{
	int i,j;

	for(i=0;i<4;i++)
	{
		if( map[3][j+3] > 8) 
		{ 
			gg=1; 
			return; 
		}
	}
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			map[i][j+3]=unit[u].arr[i][j];
		}
	}
	now=u;

	next=rand()%7;
	printnext();
}

void printmap() // ��Ʈ���� �� ���
{
	short i,j;

	for(i=3;i<17;i++)
	{
		for(j=0;j<10;j++)
		{
			lcd_clear_area(clr[map[i][j]%8],15*j+16,15*i+31-45,13,13);
		}
	}
}

void printnext() // ���� �ҷ� ���
{
	short i,j;
	short temp;

	lcd_clear_area(LGRAY,167,32,60,60);
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{	
			temp=unit[next].arr[i][j];
			if(temp) lcd_clear_area(clr[temp],15*j+169,15*i+34,13,13);
		}
	}
}

void moveleft() // �������� ������
{
	short n=0,m=0;
	short temp[4][4]={0};
	if(!sort) return;
	for(n=0; n<4; n++)
		for(m=0;m<4;m++)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!= 0)
				if(map[line-3+n][sort+m-1]>=8) { return; } //���� ������ ����!
	for(n=3; n>=0; n--)
		for(m=0;m<4;m++)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!=0)	
			{ 	
				temp[n][m] = map[line-3+n][sort+m];
				map[line-3+n][sort+m] = 0;
				map[line-3+n][sort+m-1]=temp[n][m]; 
			}
	sort--;
}

void movedown() // �Ʒ��� ������
{
	short n=0,m=0;
	short temp[4][4]={0};
	for(n=0; n<4; n++)
		for(m=0;m<4;m++)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!= 0)
				if(map[line-3+n+1][sort+m]>=8) { stack_unit(); er_line(); insert2m(next); return; } // ���� ������ ���� �����ϰ�,���� ���� Ȯ���ϰ� ����!
	for(n=3; n>=0; n--)
		for(m=3;m>=0;m--)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!=0)	
			{ 	
				temp[n][m] = map[line-3+n][sort+m];
				map[line-3+n][sort+m] = 0;
				map[line-3+n+1][sort+m]=temp[n][m]; 
			}
	line++;
	sec=1;
}

void moveright() //���������� ������
{
	short n=0,m=0;
	short temp[4][4]={0};
	for(n=0; n<4; n++)
		for(m=3;m>=0;m--)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!= 0)
				if(map[line-3+n][sort+m+1]>=8) { return; } // ���������� �� �� ������
	for(n=3; n>=0; n--)
		for(m=3;m>=0;m--)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!=0)	
			{ 	
				temp[n][m] = map[line-3+n][sort+m];
				map[line-3+n][sort+m] = 0;
				map[line-3+n][sort+m+1]=temp[n][m]; 
			}
	sort++;
}

void turning() // ���ۺ��� ������
{
	short n=0,m=0;
	short temp[4][4]={0};
	units p;
	units *temp_u;
	temp_u=&unit[now];
	for(n=0;n<x;n++)
		temp_u=temp_u->next;
	p=*temp_u;

	for(n=0;n<4;n++)
		for(m=0;m<4;m++)
			if(p.arr[n][m]<8 && p.arr[n][m]!=0)	
				if ( map[line-3+n][sort+m] >= 8 ) return; // ���� ������...�Ф�
	for(n=0;n<4;n++)
		for(m=0;m<4;m++)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!=0)
				map[line-3+n][sort+m] = 0;
	for(n=0;n<4;n++)
		for(m=0;m<4;m++)
			if(p.arr[n][m]<8 && p.arr[n][m]!=0)	
				map[line-3+n][sort+m] = p.arr[n][m];
	x++;
}

void stack_unit() // �ٴڿ� ������ �����ǿ�!
{
	short n=0,m=0;
	for(n=3; n>=0; n--)
		for(m=3;m>=0;m--)
			if(map[line-3+n][sort+m]<8 && map[line-3+n][sort+m]!=0)	
				map[line-3+n][sort+m] += 8;
	line=3;
	sort=3;
}

void map_init() // ���� ������!
{
	int i=0,j=0;
	
	for(i=0;i<17;i++)
		for(j=0;j<10;j++)
			map[i][j]=0;
	for(i=0;i<17;i++)
		for(j=10;j<13;j++)
			map[i][j]=8;
}

void er_line() // Ȥ�� ������ �ϼ��Ǿ��ٰ���? �׷� ��������!
{
	short n,m,k,stack=0;
	for(n=16;n>=3;n--)
		if(!(!map[n][0]+!map[n][1]+!map[n][2]+!map[n][3]+!map[n][4]+!map[n][5]+!map[n][6]+!map[n][7]+!map[n][8]+!map[n][9]))
		{
			for(m=n;m>=3;m--)
				for(k=9;k>=0;k--)
				{
					map[m][k]=map[m-1][k];
				}
			n++;
			stack++;
		}
	switch(stack) // ��! �̰� ��������!
	{
		case 1 : score+=10; break;
		case 2 : score+=25; break;
		case 3 : score+=40; PORTF=0x00; _delay_ms(13); PORTF=0xff; break;
		case 4 : score+=60; PORTF=0x00; _delay_ms(13); PORTF=0xff; break;
	}
}

void in_line() // �г�Ƽ���� ���� �߰�����
{
	short r;
	short n=0,m=0;
	r=rand()%10;
	for(n=3;n<17;n++)
		for(m=0;m<10;m++)
			if(map[n-1][m]>8 || map[n-1][m]==0 && map[n][m]>8)
				map[n-1][m] = map[n][m];
	for(m=0;m<10;m++)
		if(m!=r)
			map[16][m]=rand()%7+9;
		else
			map[16][m]=0;
}

void reset() // �����ؿ�. ���� ���� 
{
	sec=0;
	dlay=0;
	a_dlay=0;
	input_d=0;
	inputed=0;
	in_stack=0;

	er=0;
	op_gg=0;
	gg=0;
	in_stack=0;
	in_l=0;
	temp_down=0;
	gamespeed=10;
	line=3, sort=3, now=0, x=0;
	nn=0,mm=0;
	score = 0;
	next=0;
	map_init();
}

int main(void) // ------------------- main ------------------ main --------------------
{
	int r=0;
	int i=0;
	
	port_init(); // ��Ʈ �ʱ�ȭ
	lcd_init(); // ���ϻ���
	Timer_8bit_Init();
	interruptlnit();
	unit_init(); // ���� ��� �ʱ�ȭ
	map_init(); // �� �ʱ�ȭ

	srand(seed); // �ð��� �����̰� ������ �ð��̴�
	r=rand()%7;
	insert2m(r);	
	
	lcd_clear_screen(LGRAY); // �⺻ ��Ʈ���� ȭ�� �����.....
	lcd_clear_area(GRAYBLUE,15,30,150,210);
	lcd_clear_area(GRAY,165,30,65,210);
	lcd_clear_area(GRAY,15,240,215,60);
	lcd_clear_area(DARKGRAY,20,242,60,56);
	for(i=0;i<20;i++)
		lcd_clear_area(BLUE,57-i,250+i,1,40-2*i);
	lcd_clear_area(DARKGRAY,90,242,60,56);
	for(i=0;i<20;i++)
		lcd_clear_area(BLUE,102+i,261+i,40-2*i,1);
	lcd_clear_area(DARKGRAY,160,242,60,56);
	for(i=0;i<20;i++)
		lcd_clear_area(BLUE,178+i,250+i,1,40-2*i);
	lcd_clear_area(DARKGRAY,167,175,60,56);

	lcd_display_string("NEXT",BLACK,LGRAY,24,1);
	lcd_clear_area(LGRAY,167,32,60,60); // �������!

	printmap();
	printnext();
	while(1)
	{
		lcd_clear_screen(LGRAY);
		lcd_display_string("Battle",BLACK,LGRAY,4,3);
		lcd_display_string("Tetris",BLACK,LGRAY,4,5);	
		lcd_display_string(" Game",BLACK,LGRAY,4,7);
		
		lcd_clear_area(LIGHTBLUE,80,145,80,40);
		lcd_clear_area(LIGHTBLUE,80,200,80,40);

		lcd_display_string("1 Player",BLACK,LIGHTBLUE,11,10);
		lcd_display_string("2 Player",BLACK,LIGHTBLUE,11,13);
		while(g_state==0)
		{
			read_res=Read_Continue();
			if(read_res==0) 
			{ 
				if(isBox(80,145,160,185)) 
				{
					play_n=1; g_state=1; reset(); lcd_clear_screen(LGRAY); break; // 1�ο�!
				}
				else if(isBox(80,200,160,240)) 
				{
					play_n=2; g_state=1; reset(); lcd_clear_screen(LGRAY); break; // 2�ο�!
				}
			}
		}
		insert2m(rand()%7);	
	
		lcd_clear_screen(LGRAY);
		lcd_clear_area(GRAYBLUE,15,30,150,210);
		lcd_clear_area(GRAY,165,30,65,210);
		lcd_clear_area(GRAY,15,240,215,60);
		lcd_clear_area(DARKGRAY,20,242,60,56);
		for(i=0;i<20;i++)
			lcd_clear_area(BLUE,57-i,250+i,1,40-2*i);
		lcd_clear_area(DARKGRAY,90,242,60,56);
		for(i=0;i<20;i++)
			lcd_clear_area(BLUE,102+i,261+i,40-2*i,1);
		lcd_clear_area(DARKGRAY,160,242,60,56);
		for(i=0;i<20;i++)
			lcd_clear_area(BLUE,178+i,250+i,1,40-2*i);
		lcd_clear_area(DARKGRAY,167,175,60,56);

		lcd_display_string("NEXT",BLACK,LGRAY,24,1);
		lcd_clear_area(LGRAY,167,32,60,60);

		printmap();
		printnext();
		in_stack=0;
		while(g_state==1) // ���⼭���� ���� �ݺ����̿���
		{
			read_res=Read_Continue();

			//display_touch_debug();
			if(read_res==0) // Ŭ���� �޾ƿ�
			{
				if(isBox(20,242,80,320)) c_left();
				else if(isBox(90,242,150,320)) c_down();
				else if(isBox(160,242,220,320)) c_right();
				else if(isBox(167,175,240,235)) c_turn();
				else if(isBox(15,30,165,240)) c_up();
			}
			if(temp_down) { c_down(); temp_down--; }

			printmap();
			lcd_display_string("SCORE : ",BLACK,LGRAY,2,1);		// ���� ���
			lcd_display_number(13,1,score,7);

			if(gg) // ���� ������
			{ 
				g_state=2; 
				break; 
			}
			if(play_n==2) // 2�ο��̶�� ���� �̰���!
			{
				if(op_gg)
				{
					g_state=2;
					break;
				}
			}
		}
		lcd_clear_screen(LGRAY);
		if (gg) lcd_display_string("You Lose",BLACK,LGRAY,4,4);
		if (op_gg) lcd_display_string("You Win",BLACK,LGRAY,4,4);
		if (play_n==1) lcd_display_string("GameOver",BLACK,LGRAY,4,4);
		lcd_display_string("Score :",BLACK,LGRAY,4,6);
		lcd_display_number(13,6,score,7);

		lcd_clear_area(LIGHTBLUE,80,160,80,50);
		lcd_display_string("Replay?",BLACK,LIGHTBLUE,11,11); // �ٽ��ҷ���? ����
		reset();
		while(g_state==2) 
		{
			read_res=Read_Continue();
			if(read_res==0)
			{
				if(isBox(80,160,160,210)) {  g_state=0; break; } // �ٽ��ϸ� ����ȭ������!
			}
			PORTF = 0x00; _delay_ms(3); PORTF = 0xff; _delay_ms(10);
		}
		
	}

} // -------------- end main ------------------ end main ------------------

int isBox(int x1, int y1, int x2, int y2)
{
	if(touch_dot.x>x1 && touch_dot.x<x2 && touch_dot.y>y1 && touch_dot.y<y2)
		return 1;
	else
		return 0;
}
 
void Timer_8bit_Init()
{
	
	TCCR0 = (1<<CS02) | (1<<CS01) | (1<<CS00); //ǥ�ظ��, ���ֺ� 1024
	TCNT0 = 100; // 10msec
	TIMSK = (1<<TOIE0); //Ÿ�̸� �����÷� ���ͷ�Ʈ ���
	sei();
}
